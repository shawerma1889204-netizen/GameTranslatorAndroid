#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [[ -z "${ANDROID_HOME:-}" ]]; then
  if [[ -d "$HOME/Android/Sdk" ]]; then export ANDROID_HOME="$HOME/Android/Sdk";
  elif [[ -d "$HOME/Library/Android/sdk" ]]; then export ANDROID_HOME="$HOME/Library/Android/sdk";
  fi
fi
if [[ -z "${ANDROID_HOME:-}" ]]; then
  echo "Android SDK not found. Install Android Studio and Android SDK 35 first." >&2
  exit 1
fi
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
escaped_sdk="${ANDROID_HOME//\\/\\\\}"
printf 'sdk.dir=%s\n' "$escaped_sdk" > local.properties

GRADLE_VERSION=8.9
TOOLS_DIR="$PWD/.tools"
GRADLE_HOME_LOCAL="$TOOLS_DIR/gradle-$GRADLE_VERSION"
if [[ ! -x "$GRADLE_HOME_LOCAL/bin/gradle" ]]; then
  mkdir -p "$TOOLS_DIR"
  echo "Downloading Gradle $GRADLE_VERSION for the first build..."
  curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$TOOLS_DIR/gradle.zip"
  unzip -q -o "$TOOLS_DIR/gradle.zip" -d "$TOOLS_DIR"
  rm "$TOOLS_DIR/gradle.zip"
fi
"$GRADLE_HOME_LOCAL/bin/gradle" wrapper --gradle-version "$GRADLE_VERSION" --distribution-type bin
./gradlew :app:assembleDebug
echo "APK: $PWD/app/build/outputs/apk/debug/app-debug.apk"
