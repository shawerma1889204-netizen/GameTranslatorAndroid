package com.gametranslator.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.util.TypedValue
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.WindowManager.LayoutParams
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "com.gametranslator.app.START_CAPTURE"
        const val ACTION_STOP = "com.gametranslator.app.STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        private const val CHANNEL_ID = "game_translation_capture"
        private const val NOTIFICATION_ID = 2407
        private const val PREFS = "game_translator_settings"
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var recognizer: TextRecognizer? = null
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private var captureThread: HandlerThread? = null
    private var captureHandler: Handler? = null
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var lastFrameAt = 0L
    @Volatile private var processing = false
    @Volatile private var lastRecognizedText = ""
    private var screenWidth = 0
    private var screenHeight = 0
    @Volatile private var stopped = false
    private val displayManager by lazy { getSystemService(Context.DISPLAY_SERVICE) as DisplayManager }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(displayId: Int) = Unit
        override fun onDisplayRemoved(displayId: Int) = Unit
        override fun onDisplayChanged(displayId: Int) {
            if (displayId != Display.DEFAULT_DISPLAY || stopped || virtualDisplay == null) return
            val metrics = DisplayMetrics()
            displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.getRealMetrics(metrics)
            if (metrics.widthPixels <= 0 || metrics.heightPixels <= 0) return
            if (metrics.widthPixels == screenWidth && metrics.heightPixels == screenHeight) return

            // Games commonly rotate to landscape after capture starts. Resize the
            // virtual display and replace its ImageReader surface rather than ending
            // the MediaProjection session.
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            val replacement = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
            replacement.setOnImageAvailableListener({ reader -> onFrameAvailable(reader) }, captureHandler)
            val previous = imageReader
            imageReader = replacement
            try {
                virtualDisplay?.resize(screenWidth, screenHeight, metrics.densityDpi)
                virtualDisplay?.setSurface(replacement.surface)
            } catch (_: Exception) {
                runCatching { replacement.close() }
                imageReader = previous
                return
            }
            runCatching { previous?.setOnImageAvailableListener(null, null) }
            runCatching { previous?.close() }
        }
    }

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            stopCapture("توقفت جلسة مشاركة الشاشة من النظام")
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopCapture("تم إيقاف الترجمة")
                return START_NOT_STICKY
            }
            ACTION_START -> startCapture(intent)
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        if (projection != null) return
        createNotificationChannel()
        val notification = buildNotification("جارٍ تجهيز الترجمة...")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ServiceCompat.startForeground(
                    this,
                    NOTIFICATION_ID,
                    notification,
                    android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (error: Exception) {
            stopSelf()
            return
        }

        if (!Settings.canDrawOverlays(this)) {
            updateNotification("يرجى السماح بالظهور فوق التطبيقات ثم أعد التشغيل")
            stopCapture("يلزم إذن الظهور فوق التطبيقات")
            return
        }

        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (resultData == null) {
            stopCapture("لم تصل موافقة التقاط الشاشة")
            return
        }

        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, resultData)
            val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
            val source = prefs.getString("source_language", "en") ?: "en"
            recognizer = createRecognizer(source)

            val metrics = DisplayMetrics()
            displayManager.getDisplay(Display.DEFAULT_DISPLAY)?.getRealMetrics(metrics)
            if (metrics.widthPixels <= 0 || metrics.heightPixels <= 0) {
                metrics.setTo(resources.displayMetrics)
            }
            screenWidth = metrics.widthPixels
            screenHeight = metrics.heightPixels
            val density = metrics.densityDpi

            captureThread = HandlerThread("GameTranslatorCapture").also { it.start() }
            captureHandler = Handler(captureThread!!.looper)
            imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2)
            imageReader!!.setOnImageAvailableListener({ reader -> onFrameAvailable(reader) }, captureHandler)

            projection!!.registerCallback(projectionCallback, captureHandler)
            displayManager.registerDisplayListener(displayListener, captureHandler)
            virtualDisplay = projection!!.createVirtualDisplay(
                "GameTranslatorScreen",
                screenWidth,
                screenHeight,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader!!.surface,
                null,
                captureHandler
            )

            showOverlay("بدأت الترجمة. انتظر ظهور النص...")
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("capture_running", true).apply()
            updateNotification("الترجمة تعمل فوق اللعبة")
        } catch (error: Exception) {
            stopCapture("تعذر بدء التقاط الشاشة: ${error.localizedMessage ?: "خطأ غير معروف"}")
        }
    }

    private fun createRecognizer(source: String): TextRecognizer = when (source) {
        "ja" -> TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build())
        "zh" -> TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build())
        "ko" -> TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        else -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private fun onFrameAvailable(reader: ImageReader) {
        val image = try { reader.acquireLatestImage() } catch (_: Exception) { null } ?: return
        val now = SystemClock.elapsedRealtime()
        if (processing || now - lastFrameAt < 1300L) {
            image.close()
            return
        }
        lastFrameAt = now
        processing = true

        val bitmap = try { imageToBitmap(image) } catch (error: Exception) { null }
        image.close()
        if (bitmap == null) {
            processing = false
            return
        }
        val cropped = try { cropToSelectedRegion(bitmap) } catch (_: Exception) { bitmap }
        if (cropped !== bitmap) bitmap.recycle()

        val recognizerNow = recognizer
        if (recognizerNow == null) {
            cropped.recycle()
            processing = false
            return
        }

        recognizerNow.process(InputImage.fromBitmap(cropped, 0))
            .addOnSuccessListener { result ->
                val detected = result.text.trim()
                if (detected.isNotBlank() && detected != lastRecognizedText) {
                    lastRecognizedText = detected
                    val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
                    val source = prefs.getString("source_language", "en") ?: "en"
                    val target = prefs.getString("target_language", "ar") ?: "ar"
                    serviceScope.launch {
                        try {
                            val translated = OfflineTranslator.translate(this@ScreenCaptureService, detected, source, target)
                            if (translated.isNotBlank()) {
                                Handler(mainLooper).post { showOverlay(translated) }
                            }
                        } catch (error: Exception) {
                            lastRecognizedText = ""
                            Handler(mainLooper).post {
                                showOverlay("تعذرت الترجمة. افتح التطبيق واتصل بالإنترنت لتنزيل نموذج اللغة أول مرة.")
                            }
                        }
                    }
                }
            }
            .addOnFailureListener {
                // The next frame is retried; transient OCR errors must not end the session.
            }
            .addOnCompleteListener {
                cropped.recycle()
                processing = false
            }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val paddedWidth = rowStride / pixelStride
        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        buffer.rewind()
        padded.copyPixelsFromBuffer(buffer)
        val output = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return output
    }

    private fun cropToSelectedRegion(bitmap: Bitmap): Bitmap {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val left = prefs.getFloat("region_left", 0f).coerceIn(0f, 0.95f)
        val top = prefs.getFloat("region_top", 0f).coerceIn(0f, 0.95f)
        val right = prefs.getFloat("region_right", 1f).coerceIn(left + 0.05f, 1f)
        val bottom = prefs.getFloat("region_bottom", 1f).coerceIn(top + 0.05f, 1f)
        if (left == 0f && top == 0f && right == 1f && bottom == 1f) return bitmap
        val x = (left * bitmap.width).toInt().coerceIn(0, bitmap.width - 1)
        val y = (top * bitmap.height).toInt().coerceIn(0, bitmap.height - 1)
        val width = ((right - left) * bitmap.width).toInt().coerceIn(1, bitmap.width - x)
        val height = ((bottom - top) * bitmap.height).toInt().coerceIn(1, bitmap.height - y)
        return Bitmap.createBitmap(bitmap, x, y, width, height)
    }

    private fun showOverlay(text: String) {
        if (windowManager == null) windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = overlay ?: TextView(this).also { tv ->
            tv.setTextColor(android.graphics.Color.WHITE)
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            tv.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            tv.gravity = Gravity.CENTER
            tv.textDirection = TextView.TEXT_DIRECTION_FIRST_STRONG
            tv.setPadding(dp(16), dp(12), dp(16), dp(12))
            if (Build.VERSION.SDK_INT >= 21) {
                tv.background = android.graphics.drawable.GradientDrawable().apply {
                    setColor(0xE6162636.toInt())
                    setStroke(dp(1), 0xFF35D6B0.toInt())
                    cornerRadius = dp(16).toFloat()
                }
            } else {
                tv.setBackgroundColor(0xE6162636.toInt())
            }
            val type = if (Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_APPLICATION_OVERLAY else LayoutParams.TYPE_PHONE
            val params = LayoutParams(
                LayoutParams.MATCH_PARENT,
                LayoutParams.WRAP_CONTENT,
                type,
                LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_NOT_TOUCH_MODAL or LayoutParams.FLAG_NOT_TOUCHABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN or LayoutParams.FLAG_SECURE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                x = dp(12)
                y = dp(42)
                width = LayoutParams.MATCH_PARENT
            }
            try {
                windowManager?.addView(tv, params)
                overlay = tv
            } catch (_: Exception) {
                overlay = null
            }
        }
        view?.text = text
        view?.contentDescription = "ترجمة اللعبة: $text"
    }

    private fun removeOverlay() {
        overlay?.let { view -> runCatching { windowManager?.removeView(view) } }
        overlay = null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "ترجمة الشاشة أثناء اللعب",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "إشعار دائم أثناء جلسة ترجمة الشاشة" }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val stopIntent = Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 2, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
        )
        val openIntent = packageManager.getLaunchIntentForPackage(packageName)
        val openPending = openIntent?.let {
            PendingIntent.getActivity(
                this, 3, it,
                PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0
            )
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("ترجمة الألعاب")
            .setContentText(message)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(openPending)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopPending)
            .build()
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun stopCapture(reason: String) {
        if (stopped) return
        stopped = true
        runCatching { updateNotification(reason) }
        runCatching { displayManager.unregisterDisplayListener(displayListener) }
        runCatching { virtualDisplay?.release() }
        virtualDisplay = null
        runCatching { imageReader?.setOnImageAvailableListener(null, null) }
        runCatching { imageReader?.close() }
        imageReader = null
        runCatching { projection?.unregisterCallback(projectionCallback) }
        runCatching { projection?.stop() }
        projection = null
        runCatching { recognizer?.close() }
        recognizer = null
        removeOverlay()
        captureThread?.quitSafely()
        captureThread = null
        captureHandler = null
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("capture_running", false).apply()
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(STOP_FOREGROUND_REMOVE)
        } else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        stopSelf()
    }

    override fun onDestroy() {
        if (!stopped) {
            stopped = true
            runCatching { displayManager.unregisterDisplayListener(displayListener) }
            runCatching { virtualDisplay?.release() }
            runCatching { imageReader?.close() }
            runCatching { projection?.stop() }
            runCatching { recognizer?.close() }
            removeOverlay()
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("capture_running", false).apply()
        }
        serviceScope.cancel()
        captureThread?.quitSafely()
        super.onDestroy()
    }
}
