@echo off
setlocal enabledelayedexpansion
cd /d "%~dp0"

rem Find the standard Android SDK installation created by Android Studio.
if "%ANDROID_HOME%"=="" if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if "%ANDROID_SDK_ROOT%"=="" if not "%ANDROID_HOME%"=="" set "ANDROID_SDK_ROOT=%ANDROID_HOME%"
if not "%ANDROID_HOME%"=="" (
  set "SDK_ESC=%ANDROID_HOME:\=\\%"
  >local.properties echo sdk.dir=!SDK_ESC!
)

if "%ANDROID_HOME%"=="" (
  echo Android SDK not found. Install Android Studio and Android SDK 35 first.
  pause
  exit /b 1
)

if "%JAVA_HOME%"=="" if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
if "%JAVA_HOME%"=="" (
  echo JDK 17 was not found. Install Android Studio or set JAVA_HOME to JDK 17.
  pause
  exit /b 1
)
set "PATH=%JAVA_HOME%\bin;%PATH%"

set "GRADLE_VERSION=8.9"
set "TOOLS_DIR=%CD%\.tools"
set "GRADLE_HOME_LOCAL=%TOOLS_DIR%\gradle-%GRADLE_VERSION%"
if not exist "%GRADLE_HOME_LOCAL%\bin\gradle.bat" (
  if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
  echo Downloading Gradle %GRADLE_VERSION% for the first build...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%TOOLS_DIR%\gradle.zip'; Expand-Archive -Force '%TOOLS_DIR%\gradle.zip' '%TOOLS_DIR%'; Remove-Item '%TOOLS_DIR%\gradle.zip' -Force"
  if errorlevel 1 (
    echo Gradle download failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)

call "%GRADLE_HOME_LOCAL%\bin\gradle.bat" wrapper --gradle-version %GRADLE_VERSION% --distribution-type bin
if errorlevel 1 goto failed
call gradlew.bat :app:assembleDebug
if errorlevel 1 goto failed

echo.
echo APK created at:
echo %CD%\app\build\outputs\apk\debug\app-debug.apk
pause
exit /b 0

:failed
echo.
echo Build failed. Copy the error text and send it for troubleshooting.
pause
exit /b 1
